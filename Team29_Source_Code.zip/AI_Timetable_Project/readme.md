AI-Driven Scheduling System for Academic Timetables

📌 Overview
This project is an AI-based timetable scheduling system that automates academic timetable generation using Genetic Algorithm (GA) and Constraint Satisfaction Problem (CSP) concepts.

🚀 Features
- User Authentication (Login/Signup)
- Add/Delete Lectures
- Dynamic Room Management
- Default + Custom Dataset
- AI-based Timetable Generation
- Download Timetable as PDF
- Interactive UI Dashboard

🧠 Technologies Used
- Frontend: HTML, CSS, JavaScript
- Backend: Python (Flask)
- Database: SQLite
- AI Algorithm: Genetic Algorithm (GA)
- Optimization: CSP Constraints

⚙️ Installation & Setup

Step 1: Clone / Download Project
Extract ZIP file.

Step 2: Install Dependencies
```bash
pip install -r requirements.txt


Now in terminal - 
cd backend
python app.py

then
frontend/login.html



🧪 How It Works
1.User logs in
2.Adds lectures and rooms
3.System applies:
Faculty constraints
Room constraints
Preferred time constraints
4.Genetic Algorithm generates optimized timetable

📊 Output
Conflict-free timetable
Optimized scheduling
PDF export available