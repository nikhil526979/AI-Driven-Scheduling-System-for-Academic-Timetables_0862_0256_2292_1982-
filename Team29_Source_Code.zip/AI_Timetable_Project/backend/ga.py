import random

# Default (will be overridden dynamically)
rooms = ["R1", "R2", "R3", "R4"]
timeslots = ["Mon-1", "Mon-2", "Tue-1", "Tue-2"]

def fitness(timetable):
    penalty = 0

    for i in range(len(timetable)):
        for j in range(i+1, len(timetable)):

            if timetable[i]["faculty"] == timetable[j]["faculty"] and timetable[i]["time"] == timetable[j]["time"]:
                penalty += 10

            if timetable[i]["room"] == timetable[j]["room"] and timetable[i]["time"] == timetable[j]["time"]:
                penalty += 10

        if timetable[i]["preferred"] and timetable[i]["time"] != timetable[i]["preferred"]:
            penalty += 2

    return penalty

def create_solution(data):
    return [
        {
            "subject": d["subject"],
            "faculty": d["faculty"],
            "preferred": d["preferred"],
            "room": random.choice(rooms),
            "time": random.choice(timeslots)
        }
        for d in data
    ]

def genetic_algorithm(data):
    population = [create_solution(data) for _ in range(30)]

    for _ in range(100):
        population = sorted(population, key=fitness)
        new_population = population[:10]

        while len(new_population) < 30:
            parent = random.choice(population[:10]).copy()
            idx = random.randint(0, len(parent)-1)

            parent[idx]["time"] = random.choice(timeslots)
            parent[idx]["room"] = random.choice(rooms)

            new_population.append(parent)

        population = new_population

    return min(population, key=fitness)