# Default dataset (reference)

default_lectures = [
    {"subject": "OOPS", "faculty": "Rathi Sir", "preferred": "Mon-1"},
    {"subject": "DBMS", "faculty": "Gourav Sir", "preferred": "Tue-2"},
    {"subject": "CN", "faculty": "Sharma Sir", "preferred": "Wed-3"},
    {"subject": "OS", "faculty": "Verma Sir", "preferred": "Thu-4"}
]