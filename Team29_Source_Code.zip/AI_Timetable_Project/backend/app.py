from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import sqlite3
from ga import genetic_algorithm, rooms, timeslots
from data import default_lectures
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib import colors

app = Flask(__name__)

# ✅ GLOBAL CORS FIX
CORS(app)

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
    return response

@app.route('/<path:path>', methods=['OPTIONS'])
def options_handler(path):
    return '', 200


# ---------------- DATABASE ----------------
def init_db():
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS lectures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT,
            faculty TEXT,
            preferred TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS rooms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT
        )
    """)

    conn.commit()
    conn.close()

init_db()


# ---------------- AUTH ----------------
@app.route('/signup', methods=['POST'])
def signup():
    data = request.json

    conn = sqlite3.connect("users.db")
    cur = conn.cursor()

    cur.execute("INSERT INTO users (username,password) VALUES (?,?)",
                (data['username'], data['password']))

    conn.commit()
    conn.close()

    return jsonify({"message": "User created"})


@app.route('/login', methods=['POST'])
def login():
    data = request.json

    conn = sqlite3.connect("users.db")
    cur = conn.cursor()

    cur.execute("SELECT * FROM users WHERE username=? AND password=?",
                (data['username'], data['password']))

    user = cur.fetchone()
    conn.close()

    if user:
        return jsonify({"message": "Login successful"})
    return jsonify({"message": "Invalid"}), 401


# ---------------- ROOMS ----------------
@app.route('/rooms', methods=['GET'])
def get_rooms():
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()

    cur.execute("SELECT name FROM rooms")
    db_rooms = [r[0] for r in cur.fetchall()]
    conn.close()

    return jsonify(list(set(rooms + db_rooms)))


@app.route('/add_room', methods=['POST'])
def add_room():
    data = request.json

    conn = sqlite3.connect("users.db")
    cur = conn.cursor()

    cur.execute("INSERT INTO rooms (name) VALUES (?)", (data['name'],))
    conn.commit()
    conn.close()

    return jsonify({"message": "Room added"})


# ---------------- TIMESLOTS ----------------
@app.route('/timeslots', methods=['GET'])
def get_timeslots():
    return jsonify(timeslots)


# ---------------- LECTURES ----------------
@app.route('/lectures', methods=['GET'])
def get_lectures():
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()

    cur.execute("SELECT id, subject, faculty, preferred FROM lectures")
    db_data = cur.fetchall()
    conn.close()

    lectures = []

    # default dataset
    for d in default_lectures:
        lectures.append({"id": None, **d})

    # db data
    for d in db_data:
        lectures.append({
            "id": d[0],
            "subject": d[1],
            "faculty": d[2],
            "preferred": d[3]
        })

    return jsonify(lectures)


@app.route('/add_lecture', methods=['POST'])
def add_lecture():
    data = request.json

    conn = sqlite3.connect("users.db")
    cur = conn.cursor()

    cur.execute("INSERT INTO lectures (subject, faculty, preferred) VALUES (?,?,?)",
                (data['subject'], data['faculty'], data.get('preferred')))

    conn.commit()
    conn.close()

    return jsonify({"message": "Lecture added"})


@app.route('/delete_lecture/<int:id>', methods=['DELETE'])
def delete_lecture(id):
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()

    cur.execute("DELETE FROM lectures WHERE id=?", (id,))
    conn.commit()
    conn.close()

    return jsonify({"message": "Deleted"})


# ---------------- GENERATE ----------------
@app.route('/generate', methods=['GET'])
def generate():
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()

    cur.execute("SELECT subject, faculty, preferred FROM lectures")
    db_data = cur.fetchall()

    cur.execute("SELECT name FROM rooms")
    db_rooms = [r[0] for r in cur.fetchall()]

    conn.close()

    # update rooms dynamically
    global rooms
    rooms = list(set(rooms + db_rooms))

    lecture_data = default_lectures + [
        {"subject": d[0], "faculty": d[1], "preferred": d[2]}
        for d in db_data
    ]

    timetable = genetic_algorithm(lecture_data)

    return jsonify(timetable)


# ---------------- DOWNLOAD PDF ----------------
@app.route('/download', methods=['GET'])
def download():
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()

    cur.execute("SELECT subject, faculty, preferred FROM lectures")
    db_data = cur.fetchall()
    conn.close()

    lecture_data = default_lectures + [
        {"subject": d[0], "faculty": d[1], "preferred": d[2]}
        for d in db_data
    ]

    timetable = genetic_algorithm(lecture_data)

    file = "timetable.pdf"
    doc = SimpleDocTemplate(file)

    table_data = [["Subject", "Faculty", "Room", "Time"]]

    for row in timetable:
        table_data.append([
            row["subject"],
            row["faculty"],
            row["room"],
            row["time"]
        ])

    table = Table(table_data)
    table.setStyle(TableStyle([
        ('GRID', (0,0), (-1,-1), 1, colors.black)
    ]))

    doc.build([table])

    return send_file(file, as_attachment=True)


# ---------------- META ----------------
@app.route('/meta', methods=['GET'])
def meta():
    return jsonify({
        "rooms": rooms,
        "timeslots": timeslots
    })


# ---------------- RUN ----------------
if __name__ == "__main__":
    app.run(debug=True)